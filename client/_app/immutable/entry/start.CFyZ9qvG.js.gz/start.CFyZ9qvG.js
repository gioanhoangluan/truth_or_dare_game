import{a as t}from"../chunks/entry.DCJAC1k1.js";export{t as start};
